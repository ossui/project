#!/bin/bash

/var/ossec/bin/ossec-control restart