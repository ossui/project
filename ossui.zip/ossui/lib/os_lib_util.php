<?php
/* @(#) $Id: os_lib_util.php,v 1.5 2008/03/03 19:37:25 dcid Exp $ */

/* Copyright (C) 2006-2008 Daniel B. Cid <dcid@ossec.net>
 * All rights reserved.
 *
 * This program is a free software; you can redistribute it
 * and/or modify it under the terms of the GNU General Public
 * License (version 3) as published by the FSF - Free Software
 * Foundation
 */
       

/* os_util Functions.
 * They always returns NULL on failure.
 */


/* os_log($msg): Log an error message.
 */
function os_log($msg)
{
}

/* EOF */
?>
