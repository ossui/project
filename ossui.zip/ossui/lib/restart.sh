#!/bin/bash
# Script to restart OSSEC

. /var/ossec/bin/ossec-control $1